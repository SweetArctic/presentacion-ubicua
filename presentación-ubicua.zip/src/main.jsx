import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import PresentationIntro from "./PresentationIntro";
import App from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<PresentationIntro />} />
        <Route path="/app" element={<App />} />
        {/* cualquier otra ruta → /app */}
        <Route path="*" element={<Navigate to="/app" />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);

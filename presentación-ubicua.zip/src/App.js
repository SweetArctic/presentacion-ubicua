import React, { useState, useRef, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate } from "react-router-dom";  // 👈 IMPORTANTE
import slides from "./slides";
import DetailScreen from "./DetailScreen";
import "./styles.css";

export default function App() {
  const [index, setIndex] = useState(0);
  const [showDetail, setShowDetail] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const sidebarPrevState = useRef(false);
  const navigate = useNavigate(); // 👈

  const slide = slides[index];

  const next = () => setIndex((i) => Math.min(i + 1, slides.length - 1));
  const prev = () => setIndex((i) => Math.max(i - 1, 0));
  const goTo = (i) => {
    setIndex(i);
    setSidebarOpen(false);
    setShowDetail(false);
  };

  const openDetail = () => {
    sidebarPrevState.current = sidebarOpen;
    setSidebarOpen(false);
    setShowDetail(true);
  };

  const closeDetail = () => {
    setShowDetail(false);
    setSidebarOpen(sidebarPrevState.current);
  };

  useEffect(() => {
    document.body.classList.toggle("dark", darkMode);
  }, [darkMode]);

  return (
    <div className="app">
      <header className="app-header">
        <div>
          <h1>Computación Ubicua</h1>
          <p className="muted">
            Diapositiva {index + 1} / {slides.length}
          </p>
        </div>

        <div className="header-actions">
          <button
            onClick={() => setSidebarOpen((s) => !s)}
            className="ghost"
          >
            Fuentes
          </button>
          <button
            onClick={() => navigate("/")}
            className="ghost"
          >
            Presentación
          </button>
          <button onClick={() => setIndex(0)} className="ghost">
            Inicio
          </button>
          <button onClick={prev} className="ghost">
            Anterior
          </button>
          <button onClick={next} className="primary">
            Siguiente
          </button>
        </div>
      </header>

      {/* ... el resto de tu App.jsx queda igual ... */}
    </div>
  );
}
